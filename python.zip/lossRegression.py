import numpy as np
import gspread

x = [3,21,22,34,54,34,55,67,89,99]
x = np.array(x)
y = [2,22,24,65,79,82,55,130,150,199]
y = np.array(y)

def model(a, b, x):
    return a * x + b


def loss_function(a, b, x, y):
    num = len(x)
    prediction = model(a, b, x)
    return (0.5 / num) * (np.square(prediction - y)).sum()

def optimize(a, b, x, y):
    num = len(x)
    prediction = model(a, b, x)
    da = (1.0 / num) * ((prediction -y) * x).sum()
    db = (1.0 / num) * ((prediction -y).sum())
    a = a - Lr * da
    b = b - Lr * db
    return a, b

def iterate(a, b, x, y, times):
    for i in range(times):
        a, b = optimize(a, b, x, y)
    return a, b

a = np.random.rand(1)
b = np.random.rand(1)
Lr = 0.00001

gc = gspread.service_account(filename='coral-bebop-365111-8c6bf1caa516.json')
sh = gc.open("UnitySheets")
price = []
mon = list(range(1, 6))
i = 0

a,b = iterate(a, b, x, y, 1)
prediction = model(a, b, x)
loss = loss_function(a, b, x, y)
print(a, b, loss)
price.append([a, b, loss])

a,b = iterate(a,b,x,y,2)
prediction = model(a, b, x)
loss = loss_function(a,b,x,y)
print(a, b, loss)
price.append([a, b, loss])

a,b = iterate(a, b, x, y, 5)
prediction = model(a, b, x)
loss = loss_function(a, b, x, y)
print(a, b, loss)
price.append([a, b, loss])

a,b = iterate(a, b, x, y, 10)
prediction = model(a, b, x)
loss = loss_function(a, b, x, y)
print(a, b, loss)
price.append([a, b, loss])

a,b = iterate(a, b, x, y, 100)
prediction = model(a, b, x)
loss = loss_function(a, b, x, y)
print(a, b, loss)
price.append([a, b, loss])

a,b = iterate(a, b, x, y, 10000)
prediction = model(a, b, x)
loss = loss_function(a, b, x, y)
print(a, b, loss)
price.append([a, b, loss])

while i <= len(mon):
    i += 1
    if i == 0:
        continue
    else:

        sh.sheet1.update(('A' + str(i)), str(price[i - 1][0]))
        sh.sheet1.update(('B' + str(i)), str(price[i - 1][1]))
        sh.sheet1.update(('C' + str(i)), str(price[i - 1][2]))